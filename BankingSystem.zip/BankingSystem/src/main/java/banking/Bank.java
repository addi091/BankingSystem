package banking;

import java.util.LinkedHashMap;

/**
 * Private Variables:<br>
 * {@link #accounts}: List&lt;Long, Account&gt;
 */
public class Bank implements BankInterface {
	private LinkedHashMap<Long, Account> accounts;
	
	

	public Bank() {
		// complete the function
	}

	private Account getAccount(Long accountNumber) {
        return accounts.get(accountNumber);
	}

	public Long openCommercialAccount(Company company, int pin, double startingDeposit) {
		CommercialAccount cA = new CommercialAccount(company, getAccount(1L).getAccountNumber(), pin, startingDeposit);
        return cA.getAccountNumber();
	}

	public Long openConsumerAccount(Person person, int pin, double startingDeposit) {
		ConsumerAccount consumerAccount = new ConsumerAccount(person, getAccount(1L).getAccountNumber(), pin, startingDeposit);
        return consumerAccount.getAccountNumber();
	}

	public boolean authenticateUser(Long accountNumber, int pin) {
		if (accounts.containsKey(accountNumber)) {
			Account a = accounts.get(accountNumber);
			if (a.validatePin(pin)) {
				return true;
			}
		};
        return false;
	}

	public double getBalance(Long accountNumber) {
		Account a = accounts.get(accountNumber);
        return a.getBalance();
	}

	public void credit(Long accountNumber, double amount) {
		Account a = accounts.get(accountNumber);
		a.creditAccount(amount);
	}

	public boolean debit(Long accountNumber, double amount) {
		Account a = accounts.get(accountNumber);
        return a.debitAccount(amount);
	}
}
